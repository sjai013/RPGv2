﻿using UnityEngine;

namespace Battle.Abilities.AnimationBehaviour
{

    //TODO: THIS CLASS
    public class AbstractAnimationBehaviour : MonoBehaviour
    {
        void Awake()
        {

        }
    }
}

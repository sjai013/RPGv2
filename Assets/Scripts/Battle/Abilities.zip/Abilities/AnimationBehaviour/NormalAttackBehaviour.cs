﻿namespace Battle.Abilities.AnimationBehaviour
{
    public class NormalAttackBehaviour : AbstractAnimationBehaviour
    {

    }
}
